package com.newspaper.dailysummary;

public class DailySummaryDB {
}
