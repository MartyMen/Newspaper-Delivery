package com.newspaper.order;

import java.util.ArrayList;

public class OrderDB {
    private ArrayList<Order> orders;

}
