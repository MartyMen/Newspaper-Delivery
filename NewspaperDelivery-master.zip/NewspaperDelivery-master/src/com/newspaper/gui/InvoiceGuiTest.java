package com.newspaper.gui;

public class InvoiceGuiTest {
}
